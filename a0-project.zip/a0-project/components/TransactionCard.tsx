import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

export type Transaction = {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  category: string;
  note?: string;
  date: Date;
};

type Props = {
  transaction: Transaction;
  onPress: (transaction: Transaction) => void;
};

export default function TransactionCard({ transaction, onPress }: Props) {
  const isIncome = transaction.type === 'income';
  
  const getCategoryIcon = (category: string) => {
    const icons: { [key: string]: string } = {
      Food: 'food',
      Salary: 'cash',
      Bills: 'file-document',
      Shopping: 'shopping',
      Transport: 'car',
      default: 'cash',
    };
    return icons[category] || icons.default;
  };

  return (
    <TouchableOpacity 
      style={styles.card}
      onPress={() => onPress(transaction)}
    >
      <View style={styles.iconContainer}>
        <MaterialCommunityIcons 
          name={getCategoryIcon(transaction.category)} 
          size={24} 
          color={isIncome ? '#22c55e' : '#ef4444'}
        />
      </View>
      <View style={styles.content}>
        <Text style={styles.category}>{transaction.category}</Text>
        <Text style={styles.note}>{transaction.note}</Text>
        <Text style={styles.date}>
          {transaction.date.toLocaleDateString()}
        </Text>
      </View>
      <Text style={[
        styles.amount,
        { color: isIncome ? '#22c55e' : '#ef4444' }
      ]}>
        {isIncome ? '+' : '-'}${Math.abs(transaction.amount).toFixed(2)}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f3f4f6',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    marginLeft: 12,
  },
  category: {
    fontSize: 16,
    fontWeight: '600',
  },
  note: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 2,
  },
  date: {
    fontSize: 12,
    color: '#9ca3af',
    marginTop: 4,
  },
  amount: {
    fontSize: 16,
    fontWeight: '600',
  },
});