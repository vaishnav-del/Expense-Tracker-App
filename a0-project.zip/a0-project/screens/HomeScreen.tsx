import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import SummaryCard from '../components/SummaryCard';
import TransactionCard, { Transaction } from '../components/TransactionCard';

// Mock data
const mockTransactions: Transaction[] = [
  {
    id: '1',
    type: 'income',
    amount: 5000,
    category: 'Salary',
    note: 'Monthly salary',
    date: new Date('2025-04-25'),
  },
  {
    id: '2',
    type: 'expense',
    amount: 25.50,
    category: 'Food',
    note: 'Lunch at cafe',
    date: new Date('2025-04-26'),
  },
  {
    id: '3',
    type: 'expense',
    amount: 100,
    category: 'Shopping',
    note: 'Groceries',
    date: new Date('2025-04-26'),
  },
];

export default function HomeScreen({ navigation }: any) {
  const [transactions] = useState<Transaction[]>(mockTransactions);
  
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
    
  const totalExpenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);
    
  const balance = totalIncome - totalExpenses;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.welcomeText}>Hi, User 👋</Text>
          <TouchableOpacity 
            style={styles.addButton}
            onPress={() => navigation.navigate('AddTransaction')}
          >
            <MaterialCommunityIcons name="plus" size={24} color="white" />
            <Text style={styles.addButtonText}>Add Transaction</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.summaryContainer}>
          <SummaryCard
            title="Income"
            amount={totalIncome}
            icon="arrow-up-circle"
            color="#22c55e"
          />
          <SummaryCard
            title="Expenses"
            amount={totalExpenses}
            icon="arrow-down-circle"
            color="#ef4444"
          />
          <SummaryCard
            title="Balance"
            amount={balance}
            icon="scale-balance"
            color="#3b82f6"
          />
        </View>

        <View style={styles.transactionsHeader}>
          <Text style={styles.transactionsTitle}>Recent Transactions</Text>
          <TouchableOpacity>
            <Text style={styles.seeAllButton}>See All</Text>
          </TouchableOpacity>
        </View>

        {transactions.map(transaction => (
          <TransactionCard
            key={transaction.id}
            transaction={transaction}
            onPress={(t) => console.log('Transaction pressed:', t)}
          />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    padding: 16,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  addButton: {
    backgroundColor: '#3b82f6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  addButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginVertical: 16,
  },
  transactionsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  transactionsTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  seeAllButton: {
    color: '#3b82f6',
    fontSize: 14,
    fontWeight: '500',
  },
});